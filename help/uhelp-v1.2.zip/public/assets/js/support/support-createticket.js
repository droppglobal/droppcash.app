/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*************************************************************!*\
  !*** ./resources/assets/js/support/support-createticket.js ***!
  \*************************************************************/
(function ($) {
  "use strict"; //______summernote

  $('.summernote').summernote({
    placeholder: '',
    tabsize: 1,
    height: 200
  });
})(jQuery);
/******/ })()
;